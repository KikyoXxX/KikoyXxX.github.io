UTAU音源「逆巻」のMMD用3Dモデルver2.0です。



禁止事項
・実在する政治利用
・実在する宗教利用
・他者を攻撃する目的


上記3つに該当しない限りは、ご自由にお使いください。




公式HP
https://kikyoxxx.github.io/KikoyXxX.github.io/


桔梗（X連絡先:https://x.com/kk20588）